package com.cg.ems.ExpenseCodeModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseCodeModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
