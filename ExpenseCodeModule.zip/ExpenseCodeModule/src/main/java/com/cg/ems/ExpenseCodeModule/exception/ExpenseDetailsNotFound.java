package com.cg.ems.ExpenseCodeModule.exception;

public class ExpenseDetailsNotFound extends RuntimeException{
 public ExpenseDetailsNotFound(String message) {
	 super(message);
 }
}
