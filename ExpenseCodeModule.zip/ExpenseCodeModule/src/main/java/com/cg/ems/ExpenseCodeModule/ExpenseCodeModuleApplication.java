package com.cg.ems.ExpenseCodeModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseCodeModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseCodeModuleApplication.class, args);
	}

}
